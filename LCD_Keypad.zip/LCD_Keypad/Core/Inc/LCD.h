/*
 * LCD.h
 *
 *  Created on: Apr 25, 2023
 *      Author: Ayushman
 */

#ifndef INC_LCD_H_
#define INC_LCD_H_



#endif /* INC_LCD_H_ */


void print(unsigned char);
void lcd_data(unsigned char);
void lcd_cmd(unsigned char);
void lcd_display(unsigned char *,unsigned int);

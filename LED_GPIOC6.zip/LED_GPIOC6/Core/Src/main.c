/*
   Application:

   Step1:
   Step2:
   Step3:
   Step4:

   Author:

*/

#include"main.h"


void delay(int T)
{
	int i;
	while(T--)
	{
		for(i=0;i<4000;i++);
	}
}

int main()
{
	RCC->AHB1ENR |=(1<<2);           //Clock enabled.
	GPIOC->MODER |=(1<<12);          //pin PC6(bits 13:12) as Output (01)
	while(1)
	{
		GPIOC->ODR |=(1<<6);         //PIN SET.
		delay(1000);
		GPIOC->ODR &= ~(1<<6);       //PIN RESET.
		delay(1000);
	}
}

/*
 * usart.h
 *
 *  Created on: Apr 25, 2023
 *      Author: PHY202302EF03
 */

#ifndef USART_H_
#define USART_H_

void USART2_init(void);

int __io_putchar(unsigned char ch);

void USART2_transmit(unsigned char ch);

void delay(int t);

#endif /* USART_H_ */

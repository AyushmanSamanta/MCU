/*
 * lcd_driver.h
 *
 *  Created on: Apr 22, 2023
 *      Author: Acer
 */

#ifndef INC_LCD_DRIVER_H_
#define INC_LCD_DRIVER_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32f4xx_hal.h"


#define LCD_ADDRESS 0x4E

/* Function to initialize LCD */
void lcd_init (void);

/* Function to send command to LCD */
void lcd_send_cmd (char cmd);

/* Function to send data to LCD */
void lcd_send_data (char data);

/* Function to set cursor on LCD */
void lcd_set_cursor(int row, int col);

/* Function to send string to LCD */
void lcd_send_string (char *str);

/* Function to clear LCD */
void lcd_clear (void);

#ifdef __cplusplus
}
#endif

#endif /* INC_LCD_DRIVER_H_ */

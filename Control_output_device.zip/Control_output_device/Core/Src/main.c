/*
   Application:Blink LED on Button press.
   OUTPUT Device=LED=PC6
   INPUT Device=BUTTON=PC13

   PC13 is always on high state.

   Author:Ayushman Samanta.

*/

#include"main.h"

void delay(int a)
{
	int i;
	while(a--)
	{
		for(i=0;i<4000;i++);
	}
}
void toggleON(){
	GPIOA->ODR |= (1<<6);

}
void toggleOFF(){
	GPIOA->ODR &= ~(1<<6);

}



int main()
{
	RCC->AHB1ENR |= (1<<0);
	RCC->AHB1ENR |= (1<<2);
	GPIOA->MODER |=(1<<12);
	GPIOC->MODER |= 0x0;
	while (1)
	  {
		  if(!(HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_13)))
		  {
			 toggleON();
		     delay(500);
		  }
		  else
		  {
			  toggleOFF();
			  delay(500);
		  }


	  }

}

/*
   Application:

   Step1:
   Step2:
   Step3:
   Step4:

   Author:

*/

#include"main.h"


void delay(int T)
{
	int i;
	while(T--)
	{
		for(i=0;i<4000;i++);
	}
}

int main()
{
	RCC->AHB1ENR |=(1<<0);             //Clock enabled.
	GPIOA->MODER |=(1<<12);            //pin PA6(bits 13:12) as Output (01)
	while(1)
	{
		GPIOA->ODR |=(1<<6);           //PIN SET.
		delay(1000);
		GPIOA->ODR &= ~(1<<6);         //PIN RESET.
		delay(1000);
	}
}

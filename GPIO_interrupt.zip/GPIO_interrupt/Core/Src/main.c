/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"


/* Function to handle EXTI line[9:5] interrupts */
void EXTI9_5_IRQHandler(void);


int main()
{
	/* Disable the interrupt first */
	__disable_irq();

	/* Enable Clock for GPIOA */
	RCC->AHB1ENR |= (1 << 0);

	/* Enable Clock for SYSCFG */
	RCC->APB2ENR |= (1 << 14);

	/* Make GPIOA PIN 8 General purpose output */
	GPIOA->MODER |= (1 << 16);

	/* Enable the SYSCFG_EXTICR2 register */
	SYSCFG->EXTICR[1] |= (1 << 13);

	/* Unmask the interrupt request from input line PC7 */
	EXTI->IMR |= (1 << 7);

	/* Enable Falling Edge Trigger for input line PC7 */
	EXTI->RTSR |= (1 << 7);

	/* Enable interrupt for EXTI Line 7, which maps to PC7 */
	__NVIC_EnableIRQ(EXTI9_5_IRQn);

	/* Enable the interrupt */
	__enable_irq();

	while(1)
	{
		/* Do nothing here */
	}
}

/* Function to handle EXTI line[9:5] interrupts */
void EXTI9_5_IRQHandler(void)
{
	/* Toggle the state of GPIOA PIN 8 */
	GPIOA->ODR ^= (1 << 8);

	/* A small delay to avoid bouncing effect */
	for(uint32_t i = 0; i < 10000; i++);

	/* Clear the interrupt flag for EXTI Line 13 */
	EXTI->PR |= (1 << 7);
}
